package kr.or.ysedu.c702;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class C702ApplicationTests {

	@Test
	void contextLoads() {
	}

}
